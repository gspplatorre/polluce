-----------------------------------------------------------------------
-------  12.1 premio netto+imposte = premio lordo (sul multiramo il premio netto � ottenuto cumulando le garanzie)
-----------------------------------------------------------------------

----------------------------------------
--Configurazione ID script
----------------------------------------
Declare @IDSCRIPT as integer=91

if object_id('tempdb..#PE', 'U') is not null drop table #PE
select  pos=row_number() over ( order by n_progressivo), * into #PE from KPI.ParametrizzazioneEstrazioni with (nolock) where id_script = @IDSCRIPT
if object_id('tempdb..#ESTR', 'U') is not null drop table #ESTR
 
----------------------------------------
-- DEBUG
----------------------------------------
if not exists (select 1 from sys.syscolumns where object_name(id)='ParametrizzazioneEstrazioni' and name='c_prodotto')                  alter table #PE     add  c_prodotto varchar(5) null
if not exists (select 1 from sys.syscolumns where object_name(id)='ParametrizzazioneEstrazioni' and name='c_prodotto_escluso')          alter table #PE     add  c_prodotto_escluso varchar(5) null
if not exists (select 1 from sys.syscolumns where object_name(id)='ParametrizzazioneEstrazioni' and name='c_ramo_ministeriale')         alter table #PE     add c_ramo_ministeriale varchar(2) null
if not exists (select 1 from sys.syscolumns where object_name(id)='ParametrizzazioneEstrazioni' and name='c_ramo_ministeriale_escluso') alter table #PE     add c_ramo_ministeriale_escluso varchar(2) null
if not exists (select 1 from sys.syscolumns where object_name(id)='ParametrizzazioneEstrazioni' and name='c_garanzia')					alter table #PE     add c_garanzia varchar(2) null
if not exists (select 1 from sys.syscolumns where object_name(id)='ParametrizzazioneEstrazioni' and name='c_garanzia_esclusa')			alter table #PE     add c_garanzia_esclusa varchar(2) null
if not exists (select 1 from sys.syscolumns where object_name(id)='ParametrizzazioneEstrazioni' and name='c_stato')                     alter table #PE     add c_stato varchar(1) null
if not exists (select 1 from sys.syscolumns where object_name(id)='ParametrizzazioneEstrazioni' and name='c_stato_escluso')             alter table #PE     add c_stato_escluso varchar(1) null
if not exists (select 1 from sys.syscolumns where object_name(id)='ParametrizzazioneEstrazioni' and name='d_Effetto')                   alter table #PE     add d_Effetto date null
if not exists (select 1 from sys.syscolumns where object_name(id)='ParametrizzazioneEstrazioni' and name='c_tipo_titolo')               alter table #PE     add c_tipo_titolo varchar(2) null
if not exists (select 1 from sys.syscolumns where object_name(id)='ParametrizzazioneEstrazioni' and name='c_tipo_titolo_escluso')       alter table #PE     add c_tipo_titolo_escluso varchar(2) null



if ( select count(*) from #PE ) = 0 
begin
       insert into #PE (n_progressivo, area_logica, tipo_kpi,   interfaccia, nome_kpi, kpi,   f_bloccante, id_script, c_Tipo_GestioneProdotto, c_Tipo_GestioneProdotto_escluso, c_ramo_ministeriale,  f_raggruppa_prodotto, c_prodotto,d_Effetto,c_attivita,c_prodotto_escluso, c_ramo_ministeriale_escluso,c_garanzia,c_garanzia_esclusa) 
                   values (     1,       'Query',      'Universo', 'Pagamento', 'UNI',    1000, 'N',          @IDSCRIPT, NULL,                    NULL,                            NULL,                'N',                  NULL,      NULL,      NULL,     NULL,								NULL,						NULL,		NULL)
    
       --select nome_kpi, kpi, id_script, c_Tipo_GestioneProdotto, c_Tipo_GestioneProdotto_escluso, c_ramo_ministeriale, c_tipo, f_raggruppa_prodotto,c_prodotto,d_Effetto,c_attivita  from #PE

end

--update #PE set c_prodotto = 'PAG06'
update #PE set c_stato = '0'



----------------------------------------
-- PARAMETRI INTERNI
----------------------------------------
Declare @ESITOOK as varchar(100)='OK'
Declare @ESITOKO as varchar(100)='KO'
Declare @AGGREGAZIONE as varchar(100)='AGGREGAZIONE'
Declare @NESSUNAAGGREGAZIONE as varchar(100)='NESSUNA AGGREGAZIONE'


Declare @AREACONTROLLO as varchar(2000)
select @AREACONTROLLO = 
         case when c_Tipo_GestioneProdotto is not null or c_Tipo_GestioneProdotto_escluso is not null     then 'GESTIONE ' else '' end
       + case when c_ramo_ministeriale is not null       then 'RAMO ' else '' end
       + case when c_garanzia is not null                then 'GARANZIA ' else '' end 
from #PE  K where  K.id_script = @IDSCRIPT

if @AREACONTROLLO ='' set @AREACONTROLLO = 'TUTTO IL PORTAFOGLIO' 

----------------------------------------
--INIZIO Query
----------------------------------------


if object_id('tempdb..#PROD', 'U') is not null drop table #PROD
select	K.pos, K.d_effetto, K.c_stato_pratica, K.c_stato,
		E.c_compagnia, E.c_prodotto, E.c_Tipo_GestioneProdotto, E.c_ramo_ministeriale, 
c_gestione = ISNULL(E.c_Tipo_GestioneProdotto,E.c_ramo_ministeriale)
into #PROD
from #PE K
join Prodotto E with (nolock) on 
    ( K.c_Tipo_GestioneProdotto is null or K.c_Tipo_GestioneProdotto =  E.c_Tipo_GestioneProdotto )
and ( K.c_ramo_ministeriale is null     or K.c_ramo_ministeriale = E.c_ramo_ministeriale )
and ( K.c_prodotto is null              or K.c_prodotto = E.c_prodotto )
and not exists ( select 1 from #PE KK where KK.c_Tipo_GestioneProdotto_escluso = E.c_Tipo_GestioneProdotto  and KK.c_Tipo_GestioneProdotto_escluso is not null )
and not exists ( select 1 from #PE KK where KK.c_ramo_ministeriale_escluso     = E.c_ramo_ministeriale      and KK.c_ramo_ministeriale_escluso is not null          )
and not exists ( select 1 from #PE KK where KK.c_prodotto_escluso              = E.c_prodotto               and KK.c_prodotto_escluso is not null                   )

--select * from #PROD

if object_id('tempdb..#POL', 'U') is not null drop table #POL
select	D.pos, D.c_Tipo_GestioneProdotto, D.c_ramo_ministeriale, D.d_effetto,
		P.c_compagnia, P.c_prodotto, P.n_polizza, P.n_posizione, n_prog = row_number() over (partition by P.c_prodotto order by P.d_effetto_polizza desc )
into #POL
from #PROD D
join Polizza P with (nolock) on P.c_compagnia=D.c_compagnia and P.c_prodotto=D.c_prodotto and  (D.d_effetto is null   or year(P.d_effetto_polizza)>=year(D.d_effetto))
join StoricoPolizza S with (nolock) on S.c_compagnia=P.c_compagnia and S.n_polizza=P.n_polizza and S.n_posizione=P.n_posizione 
									and S.c_stato=D.c_stato -- obbligatorio stato parametri in ingresso
									and S.d_inizio <= getdate() and S.d_fine > getdate() 




if object_id('tempdb..#TIPOT', 'U') is not null drop table #TIPOT
select K.pos, T.c_tipo_titolo, tipoTitolo=T.descrizione
into #TIPOT
from #PE K
join TipoTitolo T with (nolock) on (K.c_tipo_titolo is null or T.c_tipo_titolo = K.c_tipo_titolo )




if object_id('tempdb..#TIT', 'U') is not null drop table #TIT
select	P.pos, P.c_Tipo_GestioneProdotto, P.c_ramo_ministeriale,
		T.c_compagnia, T.n_polizza, T.n_posizione, P.c_prodotto,
		T.c_tipo_titolo,T.d_effetto, T.n_progressivo_titolo, T.i_premio_lordo,T.i_imposta
	

into #TIT
from #POL P
join Titolo			 T with (nolock) on T.c_compagnia=P.c_compagnia and T.n_polizza=P.n_polizza and T.n_posizione=P.n_posizione 
join #TIPOT			 TT on TT.c_tipo_titolo=T.c_tipo_titolo


if object_id('tempdb..#DETT', 'U') is not null drop table #DETT
select  T.pos, T.c_Tipo_GestioneProdotto, T.c_ramo_ministeriale,
		T.c_compagnia, T.n_polizza, T.n_posizione, T.c_prodotto, T.d_effetto,
		Importolordo_titolo		= max( isnull(T.i_premio_lordo,0) ) ,
		Imposta_titolo			= sum( isnull(D.i_imposta,0) ),
		Importonetto_dettaglio	= sum( isnull(D.i_premio_netto,0) )
into #DETT
from #TIT T
join DettaglioTitolo D with (nolock) on D.c_compagnia=T.c_compagnia and D.n_polizza=T.n_polizza and D.n_posizione=T.n_posizione and D.d_effetto=T.d_effetto and D.n_progressivo_titolo=T.n_progressivo_titolo
group by T.pos, T.c_Tipo_GestioneProdotto, T.c_ramo_ministeriale, T.c_compagnia, T.n_polizza, T.n_posizione, T.c_prodotto, T.d_effetto,T.n_progressivo_titolo

;with ESTR as 
( 
       select c_Tipo_GestioneProdotto             = P.c_Tipo_GestioneProdotto,
                c_prodotto                        = P.c_prodotto,
                d_controllo                       = cast( getdate() as date),
                n_parametro                       = P.n_polizza,
				n_conteggio                       = NULL,
				c_ramo_ministeriale               = P.c_ramo_ministeriale,
                informazioni_aggiuntive           = convert( varchar(10), P.d_effetto, 121),  
                oggetto_squadratura				  = 'netto: '+cast( Importonetto_dettaglio as varchar) + ' ' +  'imposta: '+cast( Imposta_titolo as varchar) + ' ' +  'lordo: '+cast( Importolordo_titolo as varchar),
                comparazione1                     = Importonetto_dettaglio + Imposta_titolo,
                comparazione2                     = Importolordo_titolo,
                c_raggruppamento                  = 'NO',
                c_garanzia                        = NULL,
                c_tipo_riserva                    = NULL,
                c_tipo							  = null,
                f_raggruppa_prodotto              = NULL,
				d_effetto                         = P.d_effetto,
				c_attivita                        = NULL,
                Esito                             = @EsitoKO
		
		from #PE K
		join #DETT P on P.pos=K.pos

)

----------------------------------------
--FINE Query
----------------------------------------
select K.nome_kpi, K.kpi, K.c_Tipo_GestioneProdotto,
              c_garanzia                          = E.c_garanzia,
              c_tipo                              = E.c_tipo,
              c_gestione                          = ISNULL(E.c_Tipo_GestioneProdotto,E.c_ramo_ministeriale),
              d_controllo                         = E.d_controllo,
              esito                               = E.esito,
              c_prodotto                          = E.c_prodotto,
              rag_prod							  = case when K.f_raggruppa_prodotto='S' then E.c_prodotto else NULL end,
              n_parametro                         = E.n_parametro,
              n_conteggio                         = E.n_conteggio,
              informazioni_aggiuntive			  = E.informazioni_aggiuntive,
              oggetto_squadratura				  = E.oggetto_squadratura,
	          comparazione1,comparazione2
into #ESTR
from ESTR E
join #PE K WITH(NOLOCK)      on  K.id_script = @IDSCRIPT

--select * from #ESTR
----------------------------------------
--Esito
----------------------------------------
update #ESTR set esito = @EsitoOK where comparazione1 = comparazione2   --premio netto+imposte = premio lordo (sul multiramo il premio netto � ottenuto cumulando le garanzie)

----------------------------------------
--Output
----------------------------------------
Select nome_controllo               = A.nome_kpi, 
              id_controllo          = A.kpi,
              area_controllo        = @AREACONTROLLO,
              c_garanzia            = A.c_garanzia,
              c_tipo                = A.c_tipo,
              c_gestione            = A.c_gestione,
              d_controllo           = A.d_controllo,
              esito                 = A.esito,
              livello_aggregazione  = A.Livello_aggregazione,
              c_prodotto            = A.c_prodotto,
              n_parametro           = A.n_parametro,
              n_conteggio           = A.n_conteggio,
              informazioni_aggiuntive = A.informazioni_aggiuntive,
              oggetto_squadratura   = A.oggetto_squadratura
from (
       select nome_kpi, kpi, c_tipo,       
                      c_gestione                = NULL, 
                      d_controllo, 
					  area_controllo            = @AREACONTROLLO,
                      Esito                     = @ESITOOK,  
                      Livello_aggregazione		= @AGGREGAZIONE,
                      c_prodotto                = NULL,
                      c_garanzia                = NULL,
                      n_parametro               = NULL,
                      n_conteggio               = count(E.n_parametro), 
                      informazioni_aggiuntive   = NULL,
                      oggetto_squadratura       = NULL
       from #ESTR E
       where E.Esito=@ESITOOK
       group by nome_kpi, kpi, c_tipo, d_controllo

       union

       select nome_kpi, kpi, c_tipo, c_gestione,  d_controllo, 
                      area_controllo        = @AREACONTROLLO,
                      Esito                 = @ESITOKO,  
                      Livello_aggregazione  = @NESSUNAAGGREGAZIONE,
                      E.c_prodotto,
                      E.c_garanzia,
                      E.n_parametro,
                      n_conteggio           = 1, 
                      E.informazioni_aggiuntive,
                      E.oggetto_squadratura
       from #ESTR E
       where Esito=@ESITOKO 
	   
	  
) A order by A.ESITO desc




